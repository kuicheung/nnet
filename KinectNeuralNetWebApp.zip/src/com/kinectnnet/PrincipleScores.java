package com.kinectnnet;

public class PrincipleScores {

	private Double p1,p2,p3,p4,p5,p6;
	
	public Double getP1(){
		return p1;
	}
	
	public Double getP2(){
		return p1;
	}
	
	public Double getP3(){
		return p1;
	}
	
	public Double getP4(){
		return p1;
	}
	
	public Double getP5(){
		return p1;
	}
	
	public Double getP6(){
		return p1;
	}
	
	public void setP1(Double p1){
		this.p1 = p1;
	}
	
	public void setP2(Double p2){
		this.p2 = p2;
	}
	
	public void setP3(Double p3){
		this.p3 = p3;
	}
	
	public void setP4(Double p4){
		this.p4 = p4;
	}
	
	public void setP5(Double p5){
		this.p5 = p5;
	}
	
	public void setP6(Double p6){
		this.p6 = p6;
	}
}
